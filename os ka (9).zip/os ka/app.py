# app.py  (CLEAN + UPDATED)
from flask import Flask, render_template, request, redirect, url_for, jsonify
from bank import BankAccount
import threading
import random
import time
import datetime
import atexit

app = Flask(__name__)

# -------------------------
# Application data stores
# -------------------------
accounts = {}
account_counter = 1001
thread_logs = []                 # global log lines (strings)
last_transaction_queue = []
stats = {}

# Thread live status and timeline events (for admin UI)
thread_status = {}               # thread_id -> {"status": str, "last": timestamp_str}
thread_status_lock = threading.Lock()
timeline_events = []             # list of {"thread":int, "action":str, "start":float, "end":float}
timeline_lock = threading.Lock()

# Fraud-related stores (thread-safe access)
_otp_store = {}            # account_id -> (otp_str, expiry_ts)
_otp_lock = threading.Lock()
_pending_transfers = {}   # account_id -> dict with pending transfer
_pending_lock = threading.Lock()
_fraud_alerts = []        # list of (ts, account_id, reason, details)
_alerts_lock = threading.Lock()


def log_activity(message: str):
    """Append a timestamped message to thread_logs (for admin UI)."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    thread_logs.append(f"[{timestamp}] {message}")


# -------------------------
# Fraud Monitor Definition
# -------------------------
class FraudMonitor(threading.Thread):
    def __init__(self, accounts_ref, stop_event=None):
        super().__init__(daemon=True)
        self.accounts = accounts_ref

        from collections import defaultdict, deque
        self.recent_withdrawals = defaultdict(lambda: deque())
        self.recent_lock = threading.Lock()
        self.stop_event = stop_event or threading.Event()

        # thresholds
        self.MAX_WITHDRAWALS_IN_WINDOW = 10
        self.WITHDRAWAL_WINDOW_SEC = 2.0
        self.LARGE_TRANSACTION_LIMIT = 50000.0
        self.NIGHT_START = datetime.time(0, 0, 0)
        self.NIGHT_END = datetime.time(4, 0, 0)
        self.SCAN_INTERVAL = 0.5

    def add_withdraw_event(self, account_id, ts=None):
        if ts is None:
            ts = time.time()
        with self.recent_lock:
            dq = self.recent_withdrawals[account_id]
            dq.append(ts)
            cutoff = ts - self.WITHDRAWAL_WINDOW_SEC
            while dq and dq[0] < cutoff:
                dq.popleft()

    def check_rapid_withdrawals(self, account_id):
        with self.recent_lock:
            dq = self.recent_withdrawals.get(account_id)
            if not dq:
                return False
            if len(dq) > self.MAX_WITHDRAWALS_IN_WINDOW:
                acc = self.accounts.get(account_id)
                if acc and not getattr(acc, "is_frozen", False):
                    self.freeze_account(acc, reason=f"{len(dq)} withdrawals in {self.WITHDRAWAL_WINDOW_SEC}s")
                    return True
        return False

    def freeze_account(self, acc, reason="suspicious"):
        setattr(acc, "is_frozen", True)
        self.log_alert(acc.acc_id, "freeze", reason)
        log_activity(f"🔒 Account {acc.acc_id} frozen: {reason}")

    def unfreeze_account(self, acc):
        setattr(acc, "is_frozen", False)
        self.log_alert(acc.acc_id, "unfreeze", "manual")
        log_activity(f"🔓 Account {acc.acc_id} unfrozen")

    def log_alert(self, account_id, reason, details=None):
        rec = (time.time(), account_id, reason, details)
        with _alerts_lock:
            _fraud_alerts.append(rec)

    def detect_night_activity(self, account_id, ts=None):
        if ts is None:
            ts = time.time()
        t = datetime.datetime.fromtimestamp(ts).time()
        in_night = self.NIGHT_START <= t < self.NIGHT_END
        if in_night:
            self.log_alert(account_id, "Night activity", f"Transaction at {t}")
            log_activity(f"⚠️ Night activity for {account_id} at {t}")

    def run(self):
        while not self.stop_event.is_set():
            try:
                with self.recent_lock:
                    keys = list(self.recent_withdrawals.keys())

                for acc_id in keys:
                    self.check_rapid_withdrawals(acc_id)

                # cleanup expired OTPs
                now = time.time()
                with _otp_lock:
                    expired = [aid for aid, (otp, exp) in _otp_store.items() if exp < now]
                    for aid in expired:
                        del _otp_store[aid]

                time.sleep(self.SCAN_INTERVAL)
            except Exception as e:
                log_activity(f"FraudMonitor exception: {e}")
                time.sleep(1)


# Create monitor instance
stop_event = threading.Event()
fraud_monitor = FraudMonitor(accounts, stop_event=stop_event)


def start_monitor():
    global fraud_monitor
    if not fraud_monitor.is_alive():
        fraud_monitor.start()


def stop_monitor():
    stop_event.set()
    try:
        fraud_monitor.join(timeout=2)
    except Exception:
        pass


atexit.register(stop_monitor)


# -------------------------
# OTP Functions
# -------------------------
def generate_otp_for_account(account_id, expiry_seconds=300):
    otp = random.randint(100000, 999999)
    with _otp_lock:
        _otp_store[account_id] = (str(otp), time.time() + expiry_seconds)
    print(f"[OTP] account={account_id} otp={otp}")
    log_activity(f"[OTP] generated for account {account_id}")
    return otp


def verify_otp_for_account(account_id, otp_code):
    with _otp_lock:
        rec = _otp_store.get(account_id)
        if not rec:
            return False, "No OTP pending"
        code, expiry = rec
        if time.time() > expiry:
            del _otp_store[account_id]
            return False, "OTP expired"
        if str(code) == str(otp_code):
            del _otp_store[account_id]
            return True, "OTP verified"
        return False, "Invalid OTP"


# -------------------------
# Routes
# -------------------------
@app.route('/dashboard')
def dashboard():
    # Show a simple dashboard view (could be same as admin)
    return render_template('admin.html', accounts=accounts, logs=thread_logs, thread_status=thread_status)


@app.route('/')
def index():
    return render_template('index.html', accounts=accounts, logs=thread_logs)


@app.route('/create', methods=['GET', 'POST'])
def create():
    global account_counter
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        try:
            balance = float(request.form.get('balance', 0))
        except (ValueError, TypeError):
            balance = 0.0

        acc = BankAccount(account_counter, name, balance)
        setattr(acc, "is_frozen", False)
        setattr(acc, "tx_history", [])

        accounts[account_counter] = acc
        account_counter += 1

        log_activity(f"Created account {acc.acc_id} name={name} balance={balance:.2f}")
        return redirect(url_for('index'))
    return render_template('create.html')


@app.route('/transaction/<int:acc_id>', methods=['GET', 'POST'])
def transaction(acc_id):
    # Validate account exists
    account = accounts.get(acc_id)
    if account is None:
        return redirect(url_for('index'))

    if request.method == 'POST':
        action = request.form.get('action')
        # protect against missing amount
        try:
            amount = float(request.form.get('amount', 0))
        except (ValueError, TypeError):
            amount = 0.0

        if getattr(account, "is_frozen", False):
            msg = "Account is frozen due to suspicious activity."
            return render_template('success.html', message=msg, balance=account.balance,
                                   tx_history=account.get_tx_history())

        if action == "deposit":
            msg = account.deposit(amount)
            log_activity(f"Deposit ₹{amount} on {account.acc_id}")

        elif action == "withdraw":
            msg = account.withdraw(amount)
            fraud_monitor.add_withdraw_event(account.acc_id, time.time())
            log_activity(f"Withdraw ₹{amount} on {account.acc_id}")

        elif action == "transfer":
            # get target safely
            target_raw = request.form.get('target')
            try:
                target_id = int(target_raw) if target_raw is not None and target_raw != "" else None
            except ValueError:
                target_id = None

            if target_id is None:
                msg = "No target selected for transfer."
            elif target_id not in accounts:
                msg = "Invalid target account!"
            elif target_id == acc_id:
                msg = "Cannot transfer to the same account!"
            else:
                # OTP gating
                if amount >= fraud_monitor.LARGE_TRANSACTION_LIMIT:
                    generate_otp_for_account(account.acc_id)
                    with _pending_lock:
                        _pending_transfers[account.acc_id] = {
                            "from": account.acc_id,
                            "to": target_id,
                            "amount": amount,
                            "created": time.time()
                        }
                    msg = "Large transfer requires OTP. Enter OTP to complete."
                    return render_template('verify_otp.html', account_id=account.acc_id, message=msg)

                # perform transfer
                msg = account.transfer(accounts[target_id], amount)
                # record night activity/withdraw patterns
                fraud_monitor.detect_night_activity(account.acc_id, time.time())

        else:
            msg = "Unknown action"

        return render_template('success.html', message=msg, balance=account.balance,
                               tx_history=account.get_tx_history())

    # GET -> render transaction page; pass acc_id and account keys
    with _alerts_lock:
        recent_alerts = [
            {"time": datetime.datetime.fromtimestamp(a[0]).strftime("%Y-%m-%d %H:%M:%S"),
             "acc": a[1], "reason": a[2], "details": a[3]}
            for a in _fraud_alerts[-10:]
        ]

    return render_template('transaction.html',
                           account=account,
                           acc_id=acc_id,
                           accounts=[int(a) for a in accounts.keys()],
                           alerts=recent_alerts)


@app.route('/verify_otp', methods=['POST'])
def verify_otp_route():
    try:
        account_id = int(request.form.get("account_id", 0))
    except (ValueError, TypeError):
        account_id = 0
    otp = request.form.get("otp")

    ok, msg = verify_otp_for_account(account_id, otp)
    if not ok:
        return render_template('verify_otp.html', account_id=account_id, message=f"OTP failed: {msg}")

    with _pending_lock:
        pending = _pending_transfers.get(account_id)
        if not pending:
            return render_template('verify_otp.html', account_id=account_id, message="No pending transfer.")

        src = accounts.get(pending["from"])
        dst = accounts.get(pending["to"])
        amount = pending["amount"]

        if src is None or dst is None:
            return render_template('verify_otp.html', account_id=account_id, message="Invalid pending transfer.")

        if getattr(src, "is_frozen", False):
            return render_template('verify_otp.html', message="Frozen account.")

        res = src.transfer(dst, amount)
        # remove pending only after execution attempt
        del _pending_transfers[account_id]

    log_activity(f"OTP-verified transfer {amount} from {src.acc_id} to {dst.acc_id}")

    return render_template('success.html', message=f"Transfer completed: {res}",
                           balance=src.balance, tx_history=src.get_tx_history())


# -------------------------
# Simulation Route
# -------------------------
@app.route('/simulate', methods=['GET', 'POST'])
def simulate():
    global thread_logs, last_transaction_queue, stats

    if request.method == 'POST':
        num_threads = int(request.form.get('threads', 5))
        ops_per_thread = int(request.form.get('ops', 5))
        simulate_no_locks = 'no_locks' in request.form
        algo = request.form.get('algo', 'fcfs')

        thread_logs.clear()
        initial_balances = {acc.acc_id: acc.balance for acc in accounts.values()}
        stats = {i+1: {'deposits': 0, 'withdrawals': 0, 'transfers': 0, 'errors': 0} for i in range(num_threads)}

        # reset live status & timeline
        with thread_status_lock:
            thread_status.clear()
        with timeline_lock:
            timeline_events.clear()

        threads = []
        transaction_queue = []

        thread_memory_map = [
            {"tid": i+1, "cpu": round(random.uniform(5, 50), 2),
             "mem": round(random.uniform(40, 160), 2), "state": "Running"}
            for i in range(num_threads)
        ]

        def worker(thread_id, ops):
            for _ in range(ops):
                start_ts = time.time()
                action = random.choice(["deposit", "withdraw", "transfer"])
                acc = random.choice(list(accounts.values()))
                amount = random.randint(100, 1000)

                # mark start
                with thread_status_lock:
                    thread_status[thread_id] = {
                        "status": f"Running ({action})",
                        "last": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }

                log_activity(f"Thread-{thread_id} start {action} on Acc {acc.acc_id} amount={amount}")

                try:
                    if action == "deposit":
                        stats[thread_id]['deposits'] += 1
                        acc.deposit(amount)

                    elif action == "withdraw":
                        stats[thread_id]['withdrawals'] += 1
                        acc.withdraw(amount)
                        fraud_monitor.add_withdraw_event(acc.acc_id)

                    else:
                        targets = [a for a in accounts.values() if a.acc_id != acc.acc_id]
                        if targets:
                            tgt = random.choice(targets)
                            stats[thread_id]['transfers'] += 1
                            acc.transfer(tgt, amount)

                    # simulated operation duration
                    op_duration = random.uniform(0.05, 0.2)
                    time.sleep(op_duration)

                    # record timeline event
                    end_ts = time.time()
                    with timeline_lock:
                        timeline_events.append({
                            "thread": thread_id,
                            "action": action,
                            "start": start_ts,
                            "end": end_ts
                        })

                    log_activity(f"Thread-{thread_id} finish {action} on Acc {acc.acc_id}")

                    with thread_status_lock:
                        thread_status[thread_id]["status"] = "Idle"
                        thread_status[thread_id]["last"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                except Exception as e:
                    stats[thread_id]['errors'] += 1
                    log_activity(f"Thread-{thread_id} ERROR: {e}")
                    with thread_status_lock:
                        thread_status[thread_id]["status"] = "Error"
                        thread_status[thread_id]["last"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # small sleep between ops
                time.sleep(0.05)

            # mark thread completed
            with thread_status_lock:
                thread_status[thread_id] = {"status": "Completed", "last": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

        # start workers
        for i in range(num_threads):
            t = threading.Thread(target=worker, args=(i+1, ops_per_thread))
            threads.append(t)
            t.start()

        # wait for workers
        for t in threads:
            t.join()

        final_balances = {acc.acc_id: acc.balance for acc in accounts.values()}
        last_transaction_queue = transaction_queue

        return render_template('success.html',
                               message=f"Simulation Completed!",
                               logs=thread_logs,
                               stats=stats,
                               initial_balances=initial_balances,
                               final_balances=final_balances,
                               accounts=accounts,
                               thread_memory_map=thread_memory_map,
                               scheduler_used=algo.upper()
                               )

    return render_template('simulate.html')


# -------------------------
# Gantt / Timeline data
# -------------------------
@app.route('/gantt_data')
def gantt_data():
    # Return timeline events converted to relative times (start offset from earliest)
    with timeline_lock:
        events = list(timeline_events)

    if not events:
        return jsonify([])

    earliest = min(ev["start"] for ev in events)
    data = []
    for ev in events:
        data.append({
            "Thread": f"Thread-{ev['thread']}",
            "Start": round(ev["start"] - earliest, 3),
            "End": round(ev["end"] - earliest, 3),
            "Type": ev["action"]
        })
    return jsonify(data)


# -------------------------
# Admin, Alerts, Undo/Redo
# -------------------------
@app.route('/clear_logs', methods=['POST'])
def clear_logs():
    thread_logs.clear()
    return redirect(url_for('admin'))


@app.route('/admin')
def admin():
    # pass thread_status and logs to template
    with thread_status_lock:
        status_copy = dict(thread_status)
    return render_template('admin.html', accounts=accounts, logs=thread_logs, thread_status=status_copy)


@app.route('/account/<int:acc_id>')
def account_view(acc_id):
    acc = accounts.get(acc_id)
    if not acc:
        return "Account not found!"
    return render_template('account.html', account=acc, tx_history=acc.get_tx_history())


@app.route('/undo/<int:acc_id>', methods=['POST'])
def undo(acc_id):
    accounts[acc_id].undo()
    return redirect(url_for('account_view', acc_id=acc_id))


@app.route('/redo/<int:acc_id>', methods=['POST'])
def redo(acc_id):
    accounts[acc_id].redo()
    return redirect(url_for('account_view', acc_id=acc_id))


@app.route('/logout')
def logout():
    return redirect(url_for('index'))


@app.route('/admin/fraud_alerts')
def view_alerts():
    with _alerts_lock:
        alerts = list(_fraud_alerts)
    return render_template("fraud_alerts.html", alerts=alerts)


# -------------------------
# Demo accounts + start monitor
# -------------------------
if not accounts:
    # create a couple demo accounts so you can test transfers immediately
    accounts[1001] = BankAccount(1001, "Alice", 20000.0)
    accounts[1002] = BankAccount(1002, "Bob", 5000.0)
    account_counter = 1003

if __name__ == '__main__':
    start_monitor()
    app.run(debug=True)
