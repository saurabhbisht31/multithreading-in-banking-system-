import threading, time, random
from collections import deque


class BankAccount:
    def __init__(self, acc_id, name, balance=0):
        self.acc_id = acc_id
        self.name = name
        self.balance = balance
        self.lock = threading.Lock()

        # History
        self.tx_history = []

        # Undo/Redo stacks
        self.undo_stack = []
        self.redo_stack = []

    # -------------------------------
    # History
    # -------------------------------
    def _add_history(self, ttype, amount, info=None):
        self.tx_history.append({
            "time": time.time(),
            "type": ttype,
            "amount": amount,
            "details": info
        })

    def get_tx_history(self):
        return self.tx_history

    def _push_undo(self, action, amount, target=None):
        self.undo_stack.append((action, amount, target))
        self.redo_stack.clear()

    # -------------------------------
    # Deposit
    # -------------------------------
    def deposit(self, amount):
        with self.lock:
            if amount <= 0:
                return "Amount must be > 0."

            self.balance += amount

            self._add_history("deposit", amount)
            self._push_undo("deposit", amount)

            return f"Deposited ₹{amount}. New Balance: ₹{self.balance}"

    # -------------------------------
    # Withdraw
    # -------------------------------
    def withdraw(self, amount):
        with self.lock:
            if amount <= 0:
                return "Amount must be > 0."
            if amount > self.balance:
                return "Insufficient balance."

            self.balance -= amount

            self._add_history("withdraw", amount)
            self._push_undo("withdraw", amount)

            return f"Withdrawn ₹{amount}. New Balance: ₹{self.balance}"

    # -------------------------------
    # Transfer (thread safe)
    # -------------------------------
    def transfer(self, target_account, amount):

        # Prevent self-transfer
        if target_account.acc_id == self.acc_id:
            return "Cannot transfer to the same account."

        # Lock both accounts in sorted order to avoid deadlock
        first, second = (self, target_account) if self.acc_id < target_account.acc_id else (target_account, self)

        with first.lock:
            with second.lock:
                if amount <= 0:
                    return "Amount must be > 0."
                if amount > self.balance:
                    return "Insufficient balance."

                # do transfer
                self.balance -= amount
                target_account.balance += amount

                # history
                self._add_history("transfer_sent", amount, f"to {target_account.acc_id}")
                target_account._add_history("transfer_received", amount, f"from {self.acc_id}")

                # record for undo
                self._push_undo("transfer", amount, target_account)

                return f"Transferred ₹{amount} to Account {target_account.acc_id}"

    # ==============================================================
    #                           UNDO
    # ==============================================================
    def undo(self):
        if not self.undo_stack:
            return "Nothing to undo."

        action, amount, target = self.undo_stack.pop()

        if action == "deposit":
            with self.lock:
                self.balance -= amount
                self.redo_stack.append(("deposit", amount, None))
                return f"Undo deposit ₹{amount}. Balance: ₹{self.balance}"

        if action == "withdraw":
            with self.lock:
                self.balance += amount
                self.redo_stack.append(("withdraw", amount, None))
                return f"Undo withdrawal ₹{amount}. Balance: ₹{self.balance}"

        # -----------------------------
        # Undo transfer
        # -----------------------------
        if action == "transfer":
            # lock both accounts always
            first, second = (self, target) if self.acc_id < target.acc_id else (target, self)

            with first.lock:
                with second.lock:
                    # reverse money
                    self.balance += amount
                    target.balance -= amount

                    # redo store
                    self.redo_stack.append(("transfer", amount, target))

                    return f"Undo transfer ₹{amount} to {target.acc_id}. Balance: ₹{self.balance}"

    # ==============================================================
    #                           REDO
    # ==============================================================
    def redo(self):
        if not self.redo_stack:
            return "Nothing to redo."

        action, amount, target = self.redo_stack.pop()

        if action == "deposit":
            with self.lock:
                self.balance += amount
                self.undo_stack.append(("deposit", amount, None))
                return f"Redo deposit ₹{amount}. Balance: ₹{self.balance}"

        if action == "withdraw":
            with self.lock:
                self.balance -= amount
                self.undo_stack.append(("withdraw", amount, None))
                return f"Redo withdrawal ₹{amount}. Balance: ₹{self.balance}"

        # -----------------------------
        # Redo transfer
        # -----------------------------
        if action == "transfer":
            first, second = (self, target) if self.acc_id < target.acc_id else (target, self)

            with first.lock:
                with second.lock:
                    self.balance -= amount
                    target.balance += amount

                    self.undo_stack.append(("transfer", amount, target))

                    return f"Redo transfer ₹{amount} to {target.acc_id}. Balance: ₹{self.balance}"
