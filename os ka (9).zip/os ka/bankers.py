# bankers.py
# Minimal stub to keep project consistent
class BankersAlgorithm:
    def __init__(self):
        pass

    def is_safe(self, allocation, maximum, available):
        # Always safe in this simplified implementation
        return True
