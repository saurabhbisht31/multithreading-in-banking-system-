# fraud_monitor.py
import threading
import time
import datetime
from collections import defaultdict, deque

class FraudMonitor(threading.Thread):
    def __init__(self, accounts_ref, otp_store_ref, otp_lock_ref, alerts_ref, alerts_lock_ref, stop_event=None,
                 max_withdrawals=5, window_sec=3.0, large_limit=50000.0, night_start=(0,0,0), night_end=(4,0,0),
                 scan_interval=0.5):
        super().__init__(daemon=True)
        self.accounts = accounts_ref
        self._otp_store = otp_store_ref
        self._otp_lock = otp_lock_ref
        self._alerts = alerts_ref
        self._alerts_lock = alerts_lock_ref
        self.recent_withdrawals = defaultdict(lambda: deque())
        self.recent_lock = threading.Lock()
        self.stop_event = stop_event or threading.Event()

        self.MAX_WITHDRAWALS_IN_WINDOW = max_withdrawals
        self.WITHDRAWAL_WINDOW_SEC = window_sec
        self.LARGE_TRANSACTION_LIMIT = large_limit
        self.NIGHT_START = datetime.time(*night_start)
        self.NIGHT_END = datetime.time(*night_end)
        self.SCAN_INTERVAL = scan_interval

    def add_withdraw_event(self, account_id, ts=None):
        if ts is None:
            ts = time.time()
        with self.recent_lock:
            dq = self.recent_withdrawals[account_id]
            dq.append(ts)
            cutoff = ts - self.WITHDRAWAL_WINDOW_SEC
            while dq and dq[0] < cutoff:
                dq.popleft()

    def check_rapid_withdrawals(self, account_id):
        with self.recent_lock:
            dq = self.recent_withdrawals.get(account_id)
            if not dq:
                return False
            if len(dq) >= self.MAX_WITHDRAWALS_IN_WINDOW:
                acc = self.accounts.get(account_id)
                if acc and not getattr(acc, "is_frozen", False):
                    self.freeze_account(acc, reason=f"{len(dq)} withdrawals in {self.WITHDRAWAL_WINDOW_SEC}s")
                    return True
        return False

    def freeze_account(self, acc, reason="suspicious"):
        setattr(acc, "is_frozen", True)
        self.log_alert(acc.acc_id, "freeze", reason)

    def unfreeze_account(self, acc):
        setattr(acc, "is_frozen", False)
        self.log_alert(acc.acc_id, "unfreeze", "manual")

    def log_alert(self, account_id, reason, details=None):
        rec = (time.time(), account_id, reason, details)
        with self._alerts_lock:
            self._alerts.append(rec)

    def detect_night_activity(self, account_id, ts=None):
        if ts is None:
            ts = time.time()
        t = datetime.datetime.fromtimestamp(ts).time()
        in_night = self.NIGHT_START <= t < self.NIGHT_END
        if in_night:
            self.log_alert(account_id, "Night activity", f"Transaction at {t}")

    def run(self):
        while not self.stop_event.is_set():
            try:
                # check recent withdraws
                with self.recent_lock:
                    keys = list(self.recent_withdrawals.keys())
                for aid in keys:
                    self.check_rapid_withdrawals(aid)

                # cleanup expired OTPs
                now = time.time()
                with self._otp_lock:
                    expired = [aid for aid, (otp, exp) in self._otp_store.items() if exp < now]
                    for aid in expired:
                        del self._otp_store[aid]

                time.sleep(self.SCAN_INTERVAL)
            except Exception:
                time.sleep(1)
