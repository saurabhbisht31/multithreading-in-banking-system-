# rw_lock.py
import threading

class ReaderWriterLock:
    def __init__(self):
        self._readers = 0
        self._reader_lock = threading.Lock()
        self._writer_lock = threading.Lock()

    def acquire_read(self):
        with self._reader_lock:
            self._readers += 1
            if self._readers == 1:
                self._writer_lock.acquire()

    def release_read(self):
        with self._reader_lock:
            self._readers -= 1
            if self._readers == 0:
                self._writer_lock.release()

    def acquire_write(self):
        self._writer_lock.acquire()

    def release_write(self):
        self._writer_lock.release()
