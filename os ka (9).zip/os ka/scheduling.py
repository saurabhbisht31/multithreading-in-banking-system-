# scheduling.py
from collections import deque

# --------------------------------------------------------
#   FCFS (First Come First Serve) Gantt Chart
# --------------------------------------------------------
def gantt_chart_fcfs(processes):
    """
    processes = [ {"pid":1, "burst":4}, {"pid":2, "burst":3}, ... ]
    """
    timeline = 0
    print("\nGantt Chart (FCFS):")

    for p in processes:
        print(f"[T{p['pid']} | {p['burst']}]", end=" ")
        timeline += p["burst"]

    print(f"\nTotal Time: {timeline}")
    return timeline


# --------------------------------------------------------
#   Round Robin Gantt Chart
# --------------------------------------------------------
def gantt_chart_rr(processes, quantum=3):
    """
    processes = [ {"pid":1, "burst":5}, {"pid":2, "burst":7}, ... ]
    """
    time = 0
    ready = deque(processes)

    print("\nGantt Chart (RR):")

    while ready:
        p = ready.popleft()
        exec_time = min(p["burst"], quantum)

        print(f"[T{p['pid']} | {exec_time}]", end=" ")

        time += exec_time
        p["burst"] -= exec_time

        if p["burst"] > 0:
            ready.append(p)

    print(f"\nTotal Time: {time}")
    return time


# --------------------------------------------------------
#   Priority Scheduling Gantt Chart
# --------------------------------------------------------
def gantt_chart_priority(processes):
    """
    processes = [ {"pid":1, "burst":4, "priority":2}, ... ]
    Lower value = higher priority
    """
    timeline = 0
    sorted_ps = sorted(processes, key=lambda x: x["priority"])

    print("\nGantt Chart (Priority):")

    for p in sorted_ps:
        print(f"[T{p['pid']} P={p['priority']} | {p['burst']}]", end=" ")
        timeline += p["burst"]

    print(f"\nTotal Time: {timeline}")
    return timeline


# --------------------------------------------------------
#   Convert timeline events to Gantt chart JSON for UI
# --------------------------------------------------------
def to_gantt_format(timeline_events):
    """
    Convert thread timeline:

    timeline_events = [
        {"thread":1, "action":"deposit", "start": t1, "end": t2},
        {"thread":2, "action":"withdraw", "start": t3, "end": t4}
    ]

    Output becomes usable for the UI Gantt Chart.
    """

    if not timeline_events:
        return []

    earliest = min(e["start"] for e in timeline_events)
    formatted = []

    for ev in timeline_events:
        formatted.append({
            "Thread": f"Thread-{ev['thread']}",
            "Start": round(ev["start"] - earliest, 4),
            "End": round(ev["end"] - earliest, 4),
            "Type": ev["action"],
        })

    return formatted
