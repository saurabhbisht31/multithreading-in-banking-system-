// static/gantt.js
document.addEventListener('DOMContentLoaded', function () {
    fetch('/gantt_data')
        .then(resp => resp.json())
        .then(data => drawGantt(data));
});

function drawGantt(data) {
    const tableBody = document.querySelector("#ganttTable tbody");
    if(!tableBody) return;
    tableBody.innerHTML = "";

    if (!data || data.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="5">No data available</td></tr>`;
        return;
    }

    const maxEnd = Math.max(...data.map(x => x.End));
    const scale = 380 / (maxEnd || 1);

    data.forEach(item => {
        const duration = (item.End - item.Start).toFixed(3);
        const barWidth = (item.End - item.Start) * scale;
        const barLeft = item.Start * scale;

        const row = `
            <tr>
                <td>${item.Thread}</td>
                <td>${item.Start.toFixed(3)}</td>
                <td>${item.End.toFixed(3)}</td>
                <td>${duration}</td>
                <td>
                    <div class="timeline" style="width:400px;height:25px;background:#f3f3f3;border-radius:6px;position:relative;">
                        <div class="bar" style="position:absolute;left:${barLeft}px;width:${barWidth}px;height:100%;background:#4a90e2;border-radius:6px"></div>
                    </div>
                </td>
            </tr>
        `;
        tableBody.insertAdjacentHTML("beforeend", row);
    });
}
