# wal.py
import time
import threading
import os

class WAL:
    def __init__(self, path="wal.log"):
        self.path = path
        self.lock = threading.Lock()
        # ensure file exists
        open(self.path, "a").close()

    def log(self, line: str):
        ts = time.time()
        entry = f"{ts}|{line}\n"
        with self.lock:
            with open(self.path, "a") as f:
                f.write(entry)

    def read_all(self):
        with open(self.path, "r") as f:
            return f.read().splitlines()

    def clear(self):
        with self.lock:
            open(self.path, "w").close()
